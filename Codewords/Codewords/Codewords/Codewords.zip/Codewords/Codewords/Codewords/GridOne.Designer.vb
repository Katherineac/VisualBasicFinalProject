﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GridOne
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnHint = New System.Windows.Forms.Button()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.btnRestart = New System.Windows.Forms.Button()
        Me.lblTimer = New System.Windows.Forms.Label()
        Me.lblTimeValue = New System.Windows.Forms.Label()
        Me.gbxCodeList = New System.Windows.Forms.GroupBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.gbxCodeList.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnHint
        '
        Me.btnHint.Location = New System.Drawing.Point(816, 12)
        Me.btnHint.Name = "btnHint"
        Me.btnHint.Size = New System.Drawing.Size(75, 23)
        Me.btnHint.TabIndex = 11
        Me.btnHint.Text = "Hint"
        Me.btnHint.UseVisualStyleBackColor = True
        '
        'btnCheck
        '
        Me.btnCheck.Location = New System.Drawing.Point(816, 52)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(75, 23)
        Me.btnCheck.TabIndex = 12
        Me.btnCheck.Text = "Check"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'btnRestart
        '
        Me.btnRestart.Location = New System.Drawing.Point(816, 92)
        Me.btnRestart.Name = "btnRestart"
        Me.btnRestart.Size = New System.Drawing.Size(75, 23)
        Me.btnRestart.TabIndex = 13
        Me.btnRestart.Text = "Restart"
        Me.btnRestart.UseVisualStyleBackColor = True
        '
        'lblTimer
        '
        Me.lblTimer.AutoSize = True
        Me.lblTimer.Location = New System.Drawing.Point(482, 12)
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(36, 13)
        Me.lblTimer.TabIndex = 14
        Me.lblTimer.Text = "Timer:"
        '
        'lblTimeValue
        '
        Me.lblTimeValue.AutoSize = True
        Me.lblTimeValue.Location = New System.Drawing.Point(524, 12)
        Me.lblTimeValue.Name = "lblTimeValue"
        Me.lblTimeValue.Size = New System.Drawing.Size(34, 13)
        Me.lblTimeValue.TabIndex = 15
        Me.lblTimeValue.Text = "00:00"
        '
        'gbxCodeList
        '
        Me.gbxCodeList.Controls.Add(Me.TextBox26)
        Me.gbxCodeList.Controls.Add(Me.TextBox25)
        Me.gbxCodeList.Controls.Add(Me.TextBox24)
        Me.gbxCodeList.Controls.Add(Me.TextBox23)
        Me.gbxCodeList.Controls.Add(Me.TextBox22)
        Me.gbxCodeList.Controls.Add(Me.TextBox21)
        Me.gbxCodeList.Controls.Add(Me.TextBox20)
        Me.gbxCodeList.Controls.Add(Me.TextBox19)
        Me.gbxCodeList.Controls.Add(Me.TextBox18)
        Me.gbxCodeList.Controls.Add(Me.TextBox17)
        Me.gbxCodeList.Controls.Add(Me.TextBox16)
        Me.gbxCodeList.Controls.Add(Me.TextBox15)
        Me.gbxCodeList.Controls.Add(Me.TextBox14)
        Me.gbxCodeList.Controls.Add(Me.TextBox13)
        Me.gbxCodeList.Controls.Add(Me.TextBox12)
        Me.gbxCodeList.Controls.Add(Me.TextBox11)
        Me.gbxCodeList.Controls.Add(Me.TextBox10)
        Me.gbxCodeList.Controls.Add(Me.TextBox9)
        Me.gbxCodeList.Controls.Add(Me.TextBox8)
        Me.gbxCodeList.Controls.Add(Me.TextBox7)
        Me.gbxCodeList.Controls.Add(Me.TextBox6)
        Me.gbxCodeList.Controls.Add(Me.TextBox5)
        Me.gbxCodeList.Controls.Add(Me.TextBox4)
        Me.gbxCodeList.Controls.Add(Me.TextBox3)
        Me.gbxCodeList.Controls.Add(Me.TextBox2)
        Me.gbxCodeList.Controls.Add(Me.TextBox1)
        Me.gbxCodeList.Controls.Add(Me.Label26)
        Me.gbxCodeList.Controls.Add(Me.Label25)
        Me.gbxCodeList.Controls.Add(Me.Label24)
        Me.gbxCodeList.Controls.Add(Me.Label23)
        Me.gbxCodeList.Controls.Add(Me.Label22)
        Me.gbxCodeList.Controls.Add(Me.Label21)
        Me.gbxCodeList.Controls.Add(Me.Label20)
        Me.gbxCodeList.Controls.Add(Me.Label19)
        Me.gbxCodeList.Controls.Add(Me.Label18)
        Me.gbxCodeList.Controls.Add(Me.Label17)
        Me.gbxCodeList.Controls.Add(Me.Label16)
        Me.gbxCodeList.Controls.Add(Me.Label15)
        Me.gbxCodeList.Controls.Add(Me.Label14)
        Me.gbxCodeList.Controls.Add(Me.Label13)
        Me.gbxCodeList.Controls.Add(Me.Label12)
        Me.gbxCodeList.Controls.Add(Me.Label11)
        Me.gbxCodeList.Controls.Add(Me.Label10)
        Me.gbxCodeList.Controls.Add(Me.Label9)
        Me.gbxCodeList.Controls.Add(Me.Label8)
        Me.gbxCodeList.Controls.Add(Me.Label7)
        Me.gbxCodeList.Controls.Add(Me.Label6)
        Me.gbxCodeList.Controls.Add(Me.Label5)
        Me.gbxCodeList.Controls.Add(Me.Label4)
        Me.gbxCodeList.Controls.Add(Me.Label3)
        Me.gbxCodeList.Controls.Add(Me.Label2)
        Me.gbxCodeList.Controls.Add(Me.Label1)
        Me.gbxCodeList.Location = New System.Drawing.Point(494, 38)
        Me.gbxCodeList.Name = "gbxCodeList"
        Me.gbxCodeList.Size = New System.Drawing.Size(240, 424)
        Me.gbxCodeList.TabIndex = 16
        Me.gbxCodeList.TabStop = False
        Me.gbxCodeList.Text = "Code List"
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(145, 395)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(31, 20)
        Me.TextBox26.TabIndex = 51
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(145, 359)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(31, 20)
        Me.TextBox25.TabIndex = 50
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(145, 323)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(31, 20)
        Me.TextBox24.TabIndex = 49
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(145, 288)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(31, 20)
        Me.TextBox23.TabIndex = 48
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(145, 255)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(31, 20)
        Me.TextBox22.TabIndex = 47
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(145, 222)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(31, 20)
        Me.TextBox21.TabIndex = 46
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(145, 190)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(31, 20)
        Me.TextBox20.TabIndex = 45
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(145, 159)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(31, 20)
        Me.TextBox19.TabIndex = 44
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(145, 130)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(31, 20)
        Me.TextBox18.TabIndex = 43
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(145, 102)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(31, 20)
        Me.TextBox17.TabIndex = 42
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(145, 71)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(31, 20)
        Me.TextBox16.TabIndex = 41
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(145, 44)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(31, 20)
        Me.TextBox15.TabIndex = 40
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(145, 13)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(31, 20)
        Me.TextBox14.TabIndex = 39
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(33, 395)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(31, 20)
        Me.TextBox13.TabIndex = 38
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(33, 359)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(31, 20)
        Me.TextBox12.TabIndex = 37
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(33, 323)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(31, 20)
        Me.TextBox11.TabIndex = 36
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(33, 288)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(31, 20)
        Me.TextBox10.TabIndex = 35
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(33, 255)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(31, 20)
        Me.TextBox9.TabIndex = 34
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(33, 222)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(31, 20)
        Me.TextBox8.TabIndex = 33
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(33, 190)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(31, 20)
        Me.TextBox7.TabIndex = 32
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(33, 159)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(31, 20)
        Me.TextBox6.TabIndex = 31
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(33, 130)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(31, 20)
        Me.TextBox5.TabIndex = 30
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(33, 102)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(31, 20)
        Me.TextBox4.TabIndex = 29
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(33, 71)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(31, 20)
        Me.TextBox3.TabIndex = 28
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(33, 44)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(31, 20)
        Me.TextBox2.TabIndex = 27
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(33, 13)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(31, 20)
        Me.TextBox1.TabIndex = 26
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(117, 398)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(22, 13)
        Me.Label26.TabIndex = 25
        Me.Label26.Text = "26:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(117, 362)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(22, 13)
        Me.Label25.TabIndex = 24
        Me.Label25.Text = "25:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(117, 326)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(22, 13)
        Me.Label24.TabIndex = 23
        Me.Label24.Text = "24:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(117, 291)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(22, 13)
        Me.Label23.TabIndex = 22
        Me.Label23.Text = "23:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(117, 258)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(22, 13)
        Me.Label22.TabIndex = 21
        Me.Label22.Text = "22:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(117, 225)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(22, 13)
        Me.Label21.TabIndex = 20
        Me.Label21.Text = "21:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(117, 193)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(22, 13)
        Me.Label20.TabIndex = 19
        Me.Label20.Text = "20:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(117, 162)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(22, 13)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "19:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(117, 130)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(22, 13)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "18:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(117, 102)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(22, 13)
        Me.Label17.TabIndex = 16
        Me.Label17.Text = "17:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(117, 74)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(22, 13)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "16:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(117, 44)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(22, 13)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "15:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(117, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(22, 13)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "14:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(14, 398)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(22, 13)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "13:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(14, 362)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(22, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "12:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(14, 326)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(22, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "11:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 291)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(22, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "10:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(14, 258)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(16, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "9:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(14, 225)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(16, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "8:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(14, 193)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(16, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "7:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(14, 162)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(16, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "6:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(14, 130)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(16, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "5:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(16, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "4:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 74)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(16, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "3:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 44)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(16, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "2:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(16, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "1:"
        '
        'PlayScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(903, 477)
        Me.Controls.Add(Me.gbxCodeList)
        Me.Controls.Add(Me.lblTimeValue)
        Me.Controls.Add(Me.lblTimer)
        Me.Controls.Add(Me.btnRestart)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.btnHint)
        Me.Name = "PlayScreen"
        Me.Text = "Play Screen"
        Me.gbxCodeList.ResumeLayout(False)
        Me.gbxCodeList.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnHint As System.Windows.Forms.Button
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents btnRestart As System.Windows.Forms.Button
    Friend WithEvents lblTimer As System.Windows.Forms.Label
    Friend WithEvents lblTimeValue As System.Windows.Forms.Label
    Friend WithEvents gbxCodeList As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
